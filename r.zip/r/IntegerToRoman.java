import java.util.Scanner;
public class IntegerToRoman {

    private static int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
    private static String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};

    public static String integerToRoman(int num) {
        StringBuilder roman = new StringBuilder();
        int i = 0;
        while (num > 0) {
            while (num >= values[i]) {
                num -= values[i];
                roman.append(symbols[i]);
            }
            i++;
        }
        return roman.toString();
    }

    public static void main(String[] args) {
		Scanner bok=new Scanner(System.in);
		System.out.println("Enter the number:");
        int num = bok.nextInt();
        String romanNumeral = integerToRoman(num);
        System.out.println("The Roman numeral of " + num + " is " + romanNumeral);
    }
}