class Hotel {
    String hotelName;
    int starsRank;
    static int availableRooms;

    public Hotel(String hotelName, int starsRank, int availableRooms) {
        this.hotelName = hotelName;
        this.starsRank = starsRank;
        Hotel.availableRooms = availableRooms;
    }

    public void displayHotelInfo() {
        System.out.println("Hotel Name: " + hotelName);
        System.out.println("Stars Rank: " + starsRank);
        System.out.println("Available Rooms: " + availableRooms);
    }
}

class Room {
    int roomId;
    double price;
    String roomType;

    public Room(int roomId, String roomType) {
        this.roomId = roomId;
        this.roomType = roomType;
        setRoomPrice();
    }

    public void displayRoomInfo() {
        System.out.println("Room ID: " + roomId);
        System.out.println("Room Type: " + roomType);
        System.out.println("Price per day: LKR " + price);
    }

    private void setRoomPrice() {
        switch (roomType.toLowerCase()) {
            case "single":
                price = 2000.00;
                break;
            case "double":
                price = 3500.00;
                break;
            case "triple":
                price = 5000.00;
                break;
            default:
                System.out.println("Invalid room type");
        }
    }
}

class Resident {
    int residentId;
    String name;
    int daysToStay;
    Room room;
    double finalCost;

    public Resident(int residentId, String name) {
        this.residentId = residentId;
        this.name = name;
    }

    public void reserveRoom(Room room, int daysToStay) throws DaysReservedException {
        if (daysToStay < 1) {
            throw new DaysReservedException("Days Reserved Exception: Number of days should be greater than zero.");
        }

        this.room = room;
        this.daysToStay = daysToStay;
        this.finalCost = room.price * daysToStay;

       
        Hotel.availableRooms--;

        System.out.println(name + " has reserved a " + room.roomType + " room for " + daysToStay + " days.");
        System.out.println("Final Cost: LKR " + finalCost);
        System.out.println("Available Rooms: " + Hotel.availableRooms);
    }

    public void displayResidentInfo() {
        System.out.println("Resident ID: " + residentId);
        System.out.println("Name: " + name);
        System.out.println("Days to Stay: " + daysToStay);
        room.displayRoomInfo();
        System.out.println("Final Cost: LKR " + finalCost);
    }
}

class DaysReservedException extends Exception {
    public DaysReservedException(String message) {
        super(message);
    }
}

public class HotelManagementSystem {
    public static void main(String[] args) {
        Hotel hotel = new Hotel("ABC Hotel", 4, 3);

        Room singleRoom = new Room(101, "single");
        Room doubleRoom = new Room(102, "double");
        Room tripleRoom = new Room(103, "triple");

        Resident resident1 = new Resident(1, "John");
        Resident resident2 = new Resident(2, "Alice");
        Resident resident3 = new Resident(3, "Bob");

        hotel.displayHotelInfo();

        try {
            resident1.reserveRoom(singleRoom, 3);
            resident2.reserveRoom(doubleRoom, 5);
            resident3.reserveRoom(tripleRoom, 2);
        } catch (DaysReservedException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("\nResident Information:");
        resident1.displayResidentInfo();
        resident2.displayResidentInfo();
        resident3.displayResidentInfo();
    }
}
