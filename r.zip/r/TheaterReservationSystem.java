import java.util.Scanner;

public class TheaterReservationSystem {
    private static char[][] seats;

    public static void main(String[] args) {
        initializeSeats(5, 10); // 5 rows, 10 seats per row

        while (true) {
            displaySeatingChart();
            System.out.println("1. Book a seat");
            System.out.println("2. Exit");
            System.out.print("Enter your choice: ");

            Scanner scanner = new Scanner(System.in);
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    bookSeat();
                    break;
                case 2:
                    System.out.println("Exiting the reservation system. Goodbye!");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void initializeSeats(int numRows, int numSeatsPerRow) {
        seats = new char[numRows][numSeatsPerRow];

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numSeatsPerRow; j++) {
                seats[i][j] = '*'; // Initialize all seats as unbooked
            }
        }
    }

    private static void displaySeatingChart() {
        System.out.println("Seating Chart:");
        for (int i = 0; i < seats.length; i++) {
            for (int j = 0; j < seats[i].length; j++) {
                System.out.print(seats[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    private static void bookSeat() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the row number: ");
        int row = scanner.nextInt();

        System.out.print("Enter the seat number: ");
        int seat = scanner.nextInt();

        if (isValidSeat(row, seat) && seats[row - 1][seat - 1] == '*') {
            seats[row - 1][seat - 1] = 'c'; // Mark the seat as booked
            System.out.println("Seat booked successfully!");
        } else {
            System.out.println("Invalid seat or seat already booked. Please try again.");
        }
    }

    private static boolean isValidSeat(int row, int seat) {
        return row >= 1 && row <= seats.length && seat >= 1 && seat <= seats[row - 1].length;
    }
}
