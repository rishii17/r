public class test{
	public static void main(String[] args){
		Student S1 = new Student();
		Employee S2 = new Employee();
		S1.setName("Priyangani");
		S2.setName("Thiyagarajah");
		System.out.println(S1.toString());
		System.out.println(S2.toString());
	}
}
abstract class Person{
	String name;
	String NICNum;

	void  setName(String name){
		this.name = name;
	}
	String getName(){
		return this.name;
	}
	void setNICNum(String NICNum){
		this.NICNum = NICNum;
	}
	String getNICNum(){
		return this.NICNum;
	}
	public String toString(){
		return name + "\n" + NICNum;
	}
}

class Student extends Person{
	String regNo;
	String status;
	float gpa;
	Student(){
		
	}
	Student(String regNo, String status, float gpa, String name, String NICNum){
		this.regNo = regNo;
		this.status = status;
		this. gpa = gpa;
		super.name = name;
		super.NICNum = NICNum;
	}
	void  setregNo(String regNo){
		this.regNo = regNo;
	}
	String getregNo(){
		return this.regNo;
	}
	void setStatus(String status){
		this.status = status;
	}
	String getStatus(){
		return this.status;
	}
	void setGPA(float gpa){
		this.gpa = gpa;
	}
	float getGPA(){
		return this.gpa;
	}
	public String toString(){
		return name+"\n"+ getClass();
	}	
}
class Employee extends Person{
	String empNo;
	int hire_Year;
	String dept;
	double Salary;
	Employee(){
		
	}
	Employee(String empNo, int hire_Year, String dept, double Salary){
		this.empNo = empNo;
		this.hire_Year = hire_Year;
		this.dept = dept;
		this.Salary = Salary;
	}
	void  setEmpNo(String empNo){
		this.empNo = empNo;
	}
	String getEmpNo(){
		return this.empNo;
	}
	void setHireYear(int hire_Year){
		this.hire_Year = hire_Year;
	}
	int getHireYear(){
		return this.hire_Year;
	}
	void setDept(String dept){
		this.dept = dept;
	}
	String getDept(){
		return this.dept;
	}
	void setSalary(double Salary){
		this.Salary = Salary;
	}
	double getSalary(){
		return this.Salary;
	}
	public String toString(){
		return name+"\n"+ getClass();
	}
}