import java.util.ArrayList;
import java.util.Date;
import java.util.List;

class Person {
    private String name;
    private String gender;
    private Date joinDate;

    public Person(String name, String gender, Date joinDate) {
        this.name = name;
        this.gender = gender;
        this.joinDate = joinDate;
    }

   
    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public Date getJoinDate() {
        return joinDate;
    }
}

class TeamMember extends Person {
    private int id;
    private int maxWorkingHours = 12;

    public TeamMember(String name, String gender, Date joinDate, int id) {
        super(name, gender, joinDate);
        this.id = id;
    }

    
    public int getId() {
        return id;
    }

    public int getMaxWorkingHours() {
        return maxWorkingHours;
    }
}

class Doctor extends TeamMember {
    private String specialty;
    private List<Patient> patients = new ArrayList<>();

    public Doctor(String name, String gender, Date joinDate, int id, String specialty) {
        super(name, gender, joinDate, id);
        this.specialty = specialty;
    }

    public void treatPatient(Patient patient) {
       
        patients.add(patient);
    }

    public void checkPatientReport(Patient patient) {
        
        System.out.println("Checking report for patient: " + patient.getName());
    }

   
    public String getSpecialty() {
        return specialty;
    }

    public List<Patient> getPatients() {
        return patients;
    }
}

class Intern extends Doctor {
    private SeniorDoctor supervisor;

    public Intern(String name, String gender, Date joinDate, int id, String specialty, SeniorDoctor supervisor) {
        super(name, gender, joinDate, id, specialty);
        this.supervisor = supervisor;
    }

   
    public SeniorDoctor getSupervisor() {
        return supervisor;
    }
}

class SeniorDoctor extends Doctor {
    public SeniorDoctor(String name, String gender, Date joinDate, int id, String specialty) {
        super(name, gender, joinDate, id, specialty);
    }
}

class Surgeon extends Doctor {
    public Surgeon(String name, String gender, Date joinDate, int id, String specialty) {
        super(name, gender, joinDate, id, specialty);
    }
}

class Patient extends Person {
    private Date admissionDate;
    private String report;
    private Doctor treatingDoctor;
    private int daysInHospital;

    public Patient(String name, String gender, Date birthDate, Date admissionDate) {
        super(name, gender, birthDate);
        this.admissionDate = admissionDate;
    }

    
    public Date getAdmissionDate() {
        return admissionDate;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public Doctor getTreatingDoctor() {
        return treatingDoctor;
    }

    public void setTreatingDoctor(Doctor treatingDoctor) {
        this.treatingDoctor = treatingDoctor;
    }

    public int getDaysInHospital() {
        return daysInHospital;
    }

    public void setDaysInHospital(int daysInHospital) {
        this.daysInHospital = daysInHospital;
    }
}

class Department {
    private String name;
    private List<TeamMember> staff = new ArrayList<>();

    public Department(String name) {
        this.name = name;
    }

    public void addTeamMember(TeamMember teamMember) {
        staff.add(teamMember);
    }

    public void removeTeamMember(TeamMember teamMember) {
        staff.remove(teamMember);
    }

   
    public String getName() {
        return name;
    }

    public List<TeamMember> getStaff() {
        return staff;
    }
}

class Hospital {
    private String name;
    private String address;
    private List<Patient> patients = new ArrayList<>();
    private List<Department> departments = new ArrayList<>();

    public Hospital(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public void addPatient(Patient patient) {
        patients.add(patient);
    }

    public void removePatient(Patient patient) {
        patients.remove(patient);
    }

    public void addDepartment(Department department) {
        departments.add(department);
    }

    public void removeDepartment(Department department) {
        departments.remove(department);
    }

    
    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public List<Patient> getPatients() {
        return patients;
    }

    public List<Department> getDepartments() {
        return departments;
    }
}

public class HospitalApplication {
    public static void main(String[] args) {
       
        Hospital myHospital = new Hospital("Trinco Hospital", "333 trinco road ");

      
        SeniorDoctor seniorDoctor = new SeniorDoctor("Dr. Renly", "Male", new Date(), 841, "Cardiology");
        Surgeon surgeon = new Surgeon("Dr. Novah", "Female", new Date(), 452, "Orthopedics");
        Intern intern = new Intern("Dr. Aron", "Male", new Date(), 357, "Pediatrics", seniorDoctor);

      
        Patient patient1 = new Patient("Renly", "Male", new Date(), new Date());
        Patient patient2 = new Patient("Elise", "Female", new Date(), new Date());

        
        myHospital.addPatient(patient1);
        myHospital.addPatient(patient2);

        Department cardiologyDept = new Department("Cardiology");
        cardiologyDept.addTeamMember(seniorDoctor);

        Department orthopedicsDept = new Department("Orthopedics");
        orthopedicsDept.addTeamMember(surgeon);

        Department pediatricsDept = new Department("Pediatrics");
        pediatricsDept.addTeamMember(intern);

        myHospital.addDepartment(cardiologyDept);
        myHospital.addDepartment(orthopedicsDept);
        myHospital.addDepartment(pediatricsDept);

        
        seniorDoctor.treatPatient(patient1);
        surgeon.treatPatient(patient2);
        intern.treatPatient(patient1);

        
        System.out.println(" Details :");

        displayDoctorDetails(seniorDoctor);
        displayDoctorDetails(surgeon);
        displayDoctorDetails(intern);
    }

    private static void displayDoctorDetails(Doctor doctor) {
        System.out.println("Doctor Name: " + doctor.getName());
        System.out.println("Doctor ID: " + doctor.getId());
        System.out.println("Doctor Specialty: " + doctor.getSpecialty());

        List<Patient> patients = doctor.getPatients();
        System.out.println("Patients Treated by Doctor:");
        for (Patient patient : patients) {
            System.out.println("   Patient Name: " + patient.getName());
            System.out.println("   Diagnosis Report: " + patient.getReport());
            System.out.println("   Days in Hospital: " + patient.getDaysInHospital());
        }

        System.out.println();
    }
}
