public class SavingsAccount{
	public static double annualInterestrate;
	private double savingsBalance;
	
	public SavingsAccount(){
		
	}
	public SavingsAccount(double intRate, double SavBal){
		annualInterestrate = intRate;
		savingsBalance = SavBal;
	}
	public double calculateMonthlyInterest(){
		double balance = ((savingsBalance*annualInterestrate)/12)+savingsBalance;
		return balance;
	}
	public static void modifyInterestRate(double newInterestRate){
		annualInterestrate = newInterestRate;
	}
	public void setSavingsBalance(double newBal){
		savingsBalance = newBal;
	}
	public double getSavingsBalance(){
		return savingsBalance;
	}
	public double getAnnualInterestRate(){
		return annualInterestrate;
	}
	public static void main(String[] args){
		SavingsAccount saver1= new SavingsAccount(0.04, 2000);
		SavingsAccount saver2= new SavingsAccount(0.04, 3000);
		
		System.out.println(saver1.calculateMonthlyInterest());
		System.out.println(saver2.calculateMonthlyInterest());
		
		saver1.modifyInterestRate(0.05);
		System.out.println(saver1.calculateMonthlyInterest());
		saver2.modifyInterestRate(0.05);
		System.out.println(saver2.calculateMonthlyInterest());
	}
}