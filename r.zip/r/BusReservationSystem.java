import java.util.Scanner;

class Bus {
    private final int totalSeats;
    private boolean[] seats;

    public Bus(int totalSeats) {
        this.totalSeats = totalSeats;
        this.seats = new boolean[totalSeats];
    }

    public int getTotalSeats() {
        return totalSeats;
    }

    public boolean[] getSeats() {
        return seats;
    }

    public void viewAvailableSeats(String seatType) {
        System.out.println("Available " + seatType + " Seats:");

        for (int i = 0; i < totalSeats; i++) {
            System.out.print(seatType + " Seat " + (i + 1) + ": ");
            if (seats[i]) {
                System.out.println("Occupied");
            } else {
                System.out.println("Available");
            }
        }
    }

    public void reserveSeat(int seatNumber, String seatType) {
        if (seatNumber < 1 || seatNumber > totalSeats) {
            System.out.println("Invalid seat number. Please enter a valid seat number.");
            return;
        }

        if (seats[seatNumber - 1]) {
            System.out.println("Sorry, the " + seatType + " seat is already occupied. Choose another " + seatType + " seat.");
        } else {
            seats[seatNumber - 1] = true;
            System.out.println(seatType + " Seat " + seatNumber + " reserved successfully!");
        }
    }

    public void cancelReservation(int seatNumber, String seatType) {
        if (seatNumber < 1 || seatNumber > totalSeats) {
            System.out.println("Invalid seat number. Please enter a valid seat number.");
            return;
        }

        if (seats[seatNumber - 1]) {
            seats[seatNumber - 1] = false;
            System.out.println("Reservation for " + seatType + " Seat " + seatNumber + " canceled successfully!");
        } else {
            System.out.println("No reservation found for " + seatType + " Seat " + seatNumber + ".");
        }
    }
}

public class BusReservationSystem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create AC bus object using constructor
        Bus acBus = new Bus(10);

        // Create Non-AC bus object using constructor
        Bus nonAcBus = new Bus(10);

        while (true) {
            System.out.println("\nBus Reservation System");
            System.out.println("1. View Available AC Seats");
            System.out.println("2. Reserve an AC Seat");
            System.out.println("3. Cancel AC Reservation");
            System.out.println("4. View Available Non-AC Seats");
            System.out.println("5. Reserve a Non-AC Seat");
            System.out.println("6. Cancel Non-AC Reservation");
            System.out.println("7. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    acBus.viewAvailableSeats("AC");
                    break;
                case 2:
                    reserveSeat(scanner, acBus, "AC");
                    break;
                case 3:
                    cancelReservation(scanner, acBus, "AC");
                    break;
                case 4:
                    nonAcBus.viewAvailableSeats("Non-AC");
                    break;
                case 5:
                    reserveSeat(scanner, nonAcBus, "Non-AC");
                    break;
                case 6:
                    cancelReservation(scanner, nonAcBus, "Non-AC");
                    break;
                case 7:
                    System.out.println("Exiting Bus Reservation System. Thank you!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }

    private static void reserveSeat(Scanner scanner, Bus bus, String seatType) {
        System.out.print("Enter the " + seatType + " seat number you want to reserve: ");
        int seatNumber = scanner.nextInt();
        bus.reserveSeat(seatNumber, seatType);
    }

    private static void cancelReservation(Scanner scanner, Bus bus, String seatType) {
        System.out.print("Enter the " + seatType + " seat number you want to cancel the reservation for: ");
        int seatNumber = scanner.nextInt();
        bus.cancelReservation(seatNumber, seatType);
    }
}