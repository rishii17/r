import java.util.*;
public class menu{
	public static void main(String[] args){
		Scanner input = new Scanner(System.in);
		int ans;
		int quiz_marks;
		int ass_marks;
		int mid_marks; 
		int final_marks;
		do{
			System.out.print("Enter the Student's Registration Number : ");
			String Reg_No = input.next();
			
			do{
				System.out.print("Enter the Quiz Score : ");
				quiz_marks= input.nextInt();
				if(quiz_marks>10){
					System.out.println("Invalid Input");
				}
			}while(quiz_marks>=10);
			
			do{
				System.out.print("Enter the Assignment Score : ");
				ass_marks = input.nextInt();
				if(ass_marks>10){
					System.out.println("Invalid Input");
				}
			}while(ass_marks>=10);
			
			do{
				System.out.print("Enter the Mid-Term Exam Score : ");
				mid_marks = input.nextInt();
				if(mid_marks>20){
					System.out.println("Invalid Input");
				}
			}while(mid_marks>=20);
			
			do{
				System.out.print("Enter the Final Exam Score : ");
				final_marks = input.nextInt();
				if(final_marks>60){
					System.out.println("Invalid Input");
				}
			}while(final_marks>=60);
			
			int total_marks = (quiz_marks+ass_marks+mid_marks+final_marks);
			System.out.println("Total Marks"+ total_marks);
			
			System.out.println("\nDo you want another student's detail??? (1/0)");
			ans = input.nextInt();
		}while(ans==1);
	}
}