
class Publication {
    String title;
    double price;

    
    public Publication() {
    }

    
    public Publication(String title, double price) {
        this.title = title;
        this.price = price;
    }

 
    public void getData() {
        System.out.println("Title: " + title);
        System.out.println("Price: $" + price);
    }


    public void print() {
        System.out.println("Publication details:");
        getData();
    }
}


interface Book {
    int accessionNumber = 0; 


    void getData();

    void print();
}


interface Magazine {
    int volumeNumber = 0; 


    void getData();

    void print();
}


class Journal extends Publication implements Magazine {
    String journalName;

   
    public Journal() {
    }

    public Journal(String title, double price, String journalName) {
        super(title, price);
        this.journalName = journalName;
    }

   
    @Override
    public void print() {
        System.out.println("Journal details:");
        getData();
        System.out.println("Journal Name: " + journalName);
    }
}

public class main {
    public static void main(String[] args) {
       
        Journal journal1 = new Journal("Journal 1", 25.0, "Science Journal");
        Journal journal2 = new Journal("Journal 2", 30.0, "Nature Journal");
        Journal journal3 = new Journal("Journal 3", 20.0, "Technology Journal");
        Journal journal4 = new Journal("Journal 4", 22.0, "Health Journal");
        Journal journal5 = new Journal("Journal 5", 18.0, "History Journal");

       
        journal1.print();
        System.out.println("--------------------");
        journal2.print();
        System.out.println("--------------------");
        journal3.print();
        System.out.println("--------------------");
        journal4.print();
        System.out.println("--------------------");
        journal5.print();
    }
}
